create definer = root@`%` view v_scores as
select `1905110002`.`u_students`.`SID`   AS `SID`,
       `1905110002`.`u_students`.`NAME`  AS `NAME`,
       `1905110002`.`u_courses`.`COURSE` AS `COURSE`,
       `1905110002`.`u_scores`.`SCORE`   AS `SCORE`
from ((`1905110002`.`u_scores` join `1905110002`.`u_students` on ((`1905110002`.`u_scores`.`STUDENT_ID` =
                                                                   `1905110002`.`u_students`.`SID`)))
         join `1905110002`.`u_courses` on ((`1905110002`.`u_scores`.`COURSE_ID` = `1905110002`.`u_courses`.`CNO`)));

