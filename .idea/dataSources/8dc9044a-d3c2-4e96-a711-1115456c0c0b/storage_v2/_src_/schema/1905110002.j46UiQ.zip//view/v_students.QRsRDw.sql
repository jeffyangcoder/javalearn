create definer = root@`%` view v_students as
select `1905110002`.`u_students`.`SID`       AS `SID`,
       `1905110002`.`u_students`.`NAME`      AS `NAME`,
       `1905110002`.`u_classes`.`CLASS`      AS `CLASS`,
       `1905110002`.`u_classes`.`DEPARTMENT` AS `DEPARTMENT`
from (`1905110002`.`u_students`
         join `1905110002`.`u_classes` on ((`1905110002`.`u_students`.`CID` = `1905110002`.`u_classes`.`CID`)));

