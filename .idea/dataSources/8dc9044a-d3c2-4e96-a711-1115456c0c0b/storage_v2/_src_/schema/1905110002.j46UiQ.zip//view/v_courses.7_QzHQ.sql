create definer = root@`%` view v_courses as
select `1905110002`.`u_courses`.`CNO`    AS `CNO`,
       `1905110002`.`u_courses`.`COURSE` AS `COURSE`,
       `1905110002`.`u_courses`.`CREDIT` AS `CREDIT`
from `1905110002`.`u_courses`;

